from sys import exit as wexit  #.......Finally stopping the program wheen indicated by the user
from math import sqrt #.................Calculating bullet's x and y speed based on pelican and boat's position
from random import randint as random #..New fish, boat and bullets position/direction and fish species selection
from os import listdir as ls

from source.imports.text_outline import * #....Creating text surfaces with outline
